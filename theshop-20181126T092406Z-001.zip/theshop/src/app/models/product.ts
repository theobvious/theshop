export class product {
    constructor(
        public id : number,
        public name : string, 
        public price : number, 
        public img : string, 
        public category : string,
        public quantity : number
    ) {}
}